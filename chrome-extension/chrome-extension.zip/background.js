// Background script for handling analytics and tracking

// Listen for tracking messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'track') {
    // Log calculator usage
    console.log('Calculator used:', request.type, 'Value:', request.value);
    
    // You could send this to Google Analytics or your own analytics
    // For now, we'll just store usage stats locally
    chrome.storage.local.get(['usageStats'], (result) => {
      const stats = result.usageStats || {
        dscr: 0,
        hardMoney: 0,
        roi: 0,
        totalCalculations: 0
      };
      
      stats[request.type] = (stats[request.type] || 0) + 1;
      stats.totalCalculations += 1;
      
      chrome.storage.local.set({ usageStats: stats });
    });
  }
});

// Set up context menu for quick access
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'openCalculator',
    title: 'Open DSCR Calculator',
    contexts: ['page']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'openCalculator') {
    chrome.action.openPopup();
  }
});
