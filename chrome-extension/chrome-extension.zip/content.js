// Content script to extract property data from real estate websites

// Function to extract price from various formats
function extractPrice(text) {
  if (!text) return null;
  
  // Remove commas and dollar signs, extract number
  const match = text.match(/[\d,]+/);
  if (match) {
    return parseInt(match[0].replace(/,/g, ''));
  }
  return null;
}

// Extract property data based on the website
function extractPropertyData() {
  const hostname = window.location.hostname;
  let propertyData = {
    price: null,
    rent: null,
    address: null,
    type: null
  };

  // Zillow extraction
  if (hostname.includes('zillow.com')) {
    // Try to find price
    const priceElement = document.querySelector('[data-test="property-value"], .list-card-price, .hdp__sc-1s2b8ok-1');
    if (priceElement) {
      propertyData.price = extractPrice(priceElement.textContent);
    }

    // Try to find rent estimate
    const rentElement = document.querySelector('[data-test="rent-zestimate-value"]');
    if (rentElement) {
      propertyData.rent = extractPrice(rentElement.textContent);
    }

    // Address
    const addressElement = document.querySelector('h1[class*="address"]');
    if (addressElement) {
      propertyData.address = addressElement.textContent.trim();
    }
  }

  // Redfin extraction
  else if (hostname.includes('redfin.com')) {
    // Price
    const priceElement = document.querySelector('.statsValue, [data-rf-test-id="abp-price"]');
    if (priceElement) {
      propertyData.price = extractPrice(priceElement.textContent);
    }

    // Rent estimate (if available)
    const rentElement = document.querySelector('[data-rf-test-id="rent-estimate"]');
    if (rentElement) {
      propertyData.rent = extractPrice(rentElement.textContent);
    }

    // Address
    const addressElement = document.querySelector('.street-address, [data-rf-test-id="abp-streetLine"]');
    if (addressElement) {
      propertyData.address = addressElement.textContent.trim();
    }
  }

  // Realtor.com extraction
  else if (hostname.includes('realtor.com')) {
    // Price
    const priceElement = document.querySelector('[data-label="property-meta-price"], .rui__sc-1ij6z0p-0');
    if (priceElement) {
      propertyData.price = extractPrice(priceElement.textContent);
    }

    // Address
    const addressElement = document.querySelector('[data-label="property-address"]');
    if (addressElement) {
      propertyData.address = addressElement.textContent.trim();
    }
  }

  return propertyData;
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getPropertyData') {
    const data = extractPropertyData();
    sendResponse(data);
  }
});

// Auto-send property data when popup opens
const propertyData = extractPropertyData();
if (propertyData.price || propertyData.rent) {
  chrome.runtime.sendMessage({
    action: 'propertyData',
    ...propertyData
  });
}
